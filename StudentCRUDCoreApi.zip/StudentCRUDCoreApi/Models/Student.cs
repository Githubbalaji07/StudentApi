﻿using System.ComponentModel.DataAnnotations;

namespace StudentCRUDCoreApi.Models
{
    public class Student
    {

            public int id { get; set; }

            [Required]
            public string name { get; set; }

             [Required]
              public string gender { get; set; }
        
             [Required]
            public int age { get; set; }

             [Required]  
            public int standard { get; set; }
        


    }
}
